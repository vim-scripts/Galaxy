##INTRO:##

   *ColorV* is a Color tool in Vim.

    With it you can:
        Choose, Change, Show, Preview, Generate, Pickup, Cache ... colors.

    To Start: 
        :ColorV
