##INTRO##

**galaxy** is a colorscheme that thousands shemes within.
    
    There are several built-in schemes.
    You can get 100+ by ':GalaxyAuto' in a colorlist ':ColorVlist'.
    Also you can define yours in simply by ':GalaxyNew'.
        
    There are |galaxy-terminal| support for all schemes .

    Other features include: 
        |galaxy-edit|, |galaxy-style|,
        |galaxy-statusline-blink|, |galaxy-indent-highlight| ...

    To start:     
        :Galaxy 

    To keep using it:
        put this in your vimrc.
        colorscheme galaxy

    If you have any issues or Suggestions:
          Post it at https://github.com/Rykka/vim-galaxy

**NOTE:**   ColorV required if download from github.
            https://github.com/Rykka/ColorV

